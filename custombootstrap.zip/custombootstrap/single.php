<?php get_header(); ?>
      <div class="row">
        <div class="col-sm-8 blog-main">
          <?php if(have_posts()) : ?>
            <?php while(have_posts()) : the_post(); ?>
            <?php echo "<h1>".the_title()."</h1>"; ?>
          <?php endwhile; ?>
        <?php else : ?>
          <p><?php __('No Posts Found'); ?></p>
        <?php endif; ?>

        </div><!-- /.blog-main -->

    <?php get_footer(); ?>
