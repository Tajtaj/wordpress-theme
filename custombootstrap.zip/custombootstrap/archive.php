<?php
?>      <div class="row">
        <h1>Archive page ..............</h1>

        </div><!-- /.blog-main -->
