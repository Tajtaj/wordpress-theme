<?php
  function wpb_customize_register1($wp_customize){
    // Showcase Section
    $wp_customize->add_section('showcase', array(
      'title'   => __('Showcase', 'wpbootstrap1'),
      'description' => sprintf(__('Options for showcase','wpbootstrap1')),
      'priority'    => 130
    ));

    $wp_customize->add_setting('showcase_heading', array(
      'default'   => _x('Welcome to Scrolling Nav', 'wpbootstrap1'),
      'type'      => 'theme_mod'
    ));

    $wp_customize->add_control('showcase_heading', array(
      'label'   => __('Heading', 'wpbootstrap1'),
      'section' => 'showcase',
      'priority'  => 2
    ));

    $wp_customize->add_setting('showcase_text', array(
      'default'   => _x('A landing page template freshly redesigned for Bootstrap 4', 'wpbootstrap1'),
      'type'      => 'theme_mod'
    ));
    $wp_customize->add_control('showcase_text', array(
      'label'   => __('Text', 'wpbootstrap'),
      'section' => 'showcase',
      'priority'  => 3
    ));
  }

  add_action('customize_register', 'wpb_customize_register1');
